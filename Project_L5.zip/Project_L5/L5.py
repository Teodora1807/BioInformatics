import random
from collections import defaultdict, Counter

MIN_SEQ_LEN, MAX_SEQ_LEN = 1000, 3000
N_READS = 2000
READ_MIN, READ_MAX = 100, 150

random.seed(42)

def generate_random_dna(min_len=MIN_SEQ_LEN, max_len=MAX_SEQ_LEN):
    """Generate random DNA with small repeats."""
    L = random.randint(min_len, max_len)
    alphabet = "ACGT"
    motif = "ATG" * 15 + "CGTACG" * 5
    base = "".join(random.choice(alphabet) for _ in range(L - len(motif)))
    pos = random.randrange(0, len(base))
    seq = base[:pos] + motif + base[pos:]
    return seq[:L]

sequence = generate_random_dna()
print(f"✅ Synthetic DNA generated ({len(sequence)} bases)\n")

print("📦 Generating random samples...")
samples = []
for _ in range(N_READS):
    sample_len = random.randint(READ_MIN, READ_MAX)
    start = random.randint(0, len(sequence) - sample_len)
    sample = sequence[start:start + sample_len]
    samples.append((start, sample))
print(f"✅ Generated {len(samples)} samples ({READ_MIN}–{READ_MAX} bases each)\n")

print("🧩 Reconstructing sequence by majority voting...")

pos_to_bases = defaultdict(list)
for start, sample in samples:
    for i, base in enumerate(sample):
        pos_to_bases[start + i].append(base)

reconstructed = []
coverage = []

for pos in range(len(sequence)):
    bases = pos_to_bases[pos]
    if not bases:
        reconstructed.append("N") 
        coverage.append(0)
    else:
        count = Counter(bases)
        majority = count.most_common(1)[0][0]
        reconstructed.append(majority)
        coverage.append(len(bases))

reconstructed_seq = "".join(reconstructed)

errors = sum(a != b for a, b in zip(sequence, reconstructed_seq))
accuracy = (len(sequence) - errors) / len(sequence) * 100
avg_coverage = sum(coverage) / len(coverage)

print("\n📊 RESULTS")
print(f"Reconstructed length: {len(reconstructed_seq)}")
print(f"Average coverage: {avg_coverage:.1f}x")
print(f"Accuracy: {accuracy:.2f}%")
print(f"Errors: {errors}")

print("\n⚠ MAIN PROBLEM WITH THIS APPROACH:")
print("- Overlapping fragments can produce conflicting bases (especially in repeats).")
print("- Majority voting ignores structural ambiguity and phase consistency.")
print("- Repetitive regions create multiple valid alignments → false consensus.")
print("- Real assemblers use graph-based models (e.g., De Bruijn graphs) to resolve this.\n")

print("🔍 Example (first 200 bases):")
print("Original:     ", sequence[:200])
print("Reconstructed:", reconstructed_seq[:200])