Dumitru Teodora Iulia 1242EA
Ionescu Maria Magdalena 1242EA
