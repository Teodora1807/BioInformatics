import random
import time
import os
from io import StringIO
from collections import Counter
from Bio import Entrez, SeqIO
import matplotlib.pyplot as plt
import textwrap


NUM_GENOMES = 10
NUM_READS = 300       
READ_LEN_MIN = 100
READ_LEN_MAX = 150
MIN_OVERLAP = 10
OUT_DIR = "viral_assembly_output"
os.makedirs(OUT_DIR, exist_ok=True)
random.seed(42)

def search_viral_genomes(retmax=50):
    query = f"Viruses[Organism] AND complete genome[Title] AND 1000:50000[SLEN]"
    handle = Entrez.esearch(db="nucleotide", term=query, retmax=retmax)
    record = Entrez.read(handle)
    handle.close()
    return record["IdList"]

def fetch_sequence(nc_id):
    handle = Entrez.efetch(db="nucleotide", id=nc_id, rettype="fasta", retmode="text")
    text = handle.read()
    handle.close()
    rec = SeqIO.read(StringIO(text), "fasta")
    return str(rec.seq).upper(), rec.description

def sample_reads(seq, n_reads, rmin, rmax):
    reads = []
    L = len(seq)
    for _ in range(n_reads):
        rlen = random.randint(rmin, rmax)
        start = random.randint(0, L - rlen)
        reads.append(seq[start:start + rlen])
    return reads

def fast_overlap(a, b, min_len=MIN_OVERLAP):
    max_k = min(len(a), len(b))
    for k in range(max_k, min_len - 1, -1):
        if a[-k:] == b[:k]:
            return k
    return 0

def greedy_assembly(reads, min_overlap=MIN_OVERLAP):
    """Greedy linear-time assembly for speed (approximate)."""
    assembled = reads[0]
    for read in reads[1:]:
        olen = fast_overlap(assembled, read, min_overlap)
        assembled += read[olen:]
    return assembled

def gc_percent(seq):
    seq = seq.upper()
    gc = seq.count("G") + seq.count("C")
    return 100 * gc / len(seq)

ids = search_viral_genomes(retmax=100)
results = []

for nc_id in ids[:NUM_GENOMES]:
    try:
        seq, desc = fetch_sequence(nc_id)
        reads = sample_reads(seq, NUM_READS, READ_LEN_MIN, READ_LEN_MAX)
        
        t0 = time.perf_counter()
        contig = greedy_assembly(reads, MIN_OVERLAP)
        t1 = time.perf_counter()
        asm_time_ms = (t1 - t0) * 1000
        
        gc = gc_percent(seq)
        results.append((nc_id, desc, len(seq), gc, asm_time_ms))
        
        print(f"{nc_id}: len={len(seq)}, GC%={gc:.2f}, time={asm_time_ms:.2f} ms")
    except Exception as e:
        print(f"Failed {nc_id}: {e}")

gc_vals = [r[3] for r in results]
times = [r[4] for r in results]
labels = [r[0] for r in results]

plt.figure(figsize=(8,6))
plt.scatter(gc_vals, times, color='teal', s=70)
for x, y, label in zip(gc_vals, times, labels):
    plt.text(x+0.3, y, label, fontsize=8)
plt.xlabel("GC content (%)")
plt.ylabel("Assembly time (ms)")
plt.title("Viral genome assembly time vs GC%")
plt.grid(True)
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, "gc_vs_time.png"))
plt.close()

report_lines = ["Viral Assembly Analysis", "="*40, ""]
for nc_id, desc, length, gc, t_ms in results:
    report_lines.append(f"{nc_id}: length={length}, GC%={gc:.2f}, assembly_time={t_ms:.2f} ms")

report_lines.append("\nInterpretation:")
report_lines.append(textwrap.fill(
    "Points differ due to genome length, repeat content, and GC complexity. "
    "Higher GC or more complex/repetitive genomes usually take longer to assemble. "
    "Random sampling also causes small variations. Time is mainly influenced by sequence "
    "length and number of overlaps.", width=80))

with open(os.path.join(OUT_DIR, "analysis.txt"), "w") as f:
    f.write("\n".join(report_lines))

print(f"\n✅ Plot saved: {OUT_DIR}/gc_vs_time.png")
print(f"✅ Analysis saved: {OUT_DIR}/analysis.txt")