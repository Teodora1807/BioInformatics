Ionescu Maria-Magdalena
Dumitru Teodora
