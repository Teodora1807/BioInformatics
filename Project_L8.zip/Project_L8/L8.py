import random

def generate_dna(length=300):
    return ''.join(random.choice("ATCG") for _ in range(length))

def rev_comp(seq):
    comp = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C'}
    return ''.join(comp[b] for b in reversed(seq))

def find_all(seq, pattern):
    i = 0
    res = []
    while True:
        i = seq.find(pattern, i)
        if i == -1:
            break
        res.append(i)
        i += 1
    return res

def overlap(a_start, a_end, b_start, b_end):
    return max(0, min(a_end, b_end) - max(a_start, b_start))

def insert_transposon(seq,
                      pos,
                      IR_L="TACG",
                      core_len_range=(25, 40),
                      dr_len_range=(3, 5),
                      gt_list=None):

    if gt_list is None:
        gt_list = []

    core_len = random.randint(*core_len_range)
    core = generate_dna(core_len)
    IR_R = rev_comp(IR_L)
    te = IR_L + core + IR_R

    dr_len = random.randint(*dr_len_range)
    dr_seq = generate_dna(dr_len)

    left = seq[:pos]
    right = seq[pos:]
    new_seq = left + dr_seq + te + dr_seq + right

    te_start = pos + dr_len
    te_end = te_start + len(te)  

    delta = len(new_seq) - len(seq)
    updated_gt = []
    for gt in gt_list:
        gt = gt.copy()
        if gt['start'] >= pos:
            gt['start'] += delta
            gt['end'] += delta
        updated_gt.append(gt)

    updated_gt.append({
        'id': len(gt_list) + 1,
        'start': te_start,
        'end': te_end,
        'IR_L': IR_L,
        'IR_R': IR_R,
        'dr_seq': dr_seq,
    })

    return new_seq, updated_gt

def generate_sequence_with_TEs(base_len=260,
                               num_TEs=4,
                               allow_overlap=True):
    seq = generate_dna(base_len)
    gt = []

    for _ in range(num_TEs):
        if allow_overlap and gt and random.random() < 0.5:
            host = random.choice(gt)
            pos = random.randint(host['start'], host['end'])
        else:
            pos = random.randint(0, len(seq))

        seq, gt = insert_transposon(
            seq,
            pos,
            IR_L="TACG",
            core_len_range=(25, 40),
            dr_len_range=(3, 5),
            gt_list=gt
        )

    return seq, gt

def detect_transposons(seq,
                       IR_L="TACG",
                       IR_R=None,
                       dr_len_min=2,
                       dr_len_max=5,
                       min_core=10,
                       max_core=200):

    if IR_R is None:
        IR_R = rev_comp(IR_L)

    L_pos = find_all(seq, IR_L)
    R_pos = find_all(seq, IR_R)

    candidates = []

    for s in L_pos:
        for e in R_pos:
            if e <= s:
                continue

            core_len = e - (s + len(IR_L))
            if core_len < min_core or core_len > max_core:
                continue

            for dr_len in range(dr_len_min, dr_len_max + 1):
                left_start = s - dr_len
                left_end = s
                right_start = e + len(IR_R)
                right_end = right_start + dr_len

                if left_start < 0 or right_end > len(seq):
                    continue

                left = seq[left_start:left_end]
                right = seq[right_start:right_end]

                if left == right:
                    candidates.append({
                        'start': s,
                        'end': e + len(IR_R),  
                        'core_len': core_len,
                        'dr_len': dr_len,
                        'dr_seq': left
                    })
                    break  

    return candidates

def main():
    random.seed(42)  

    seq, ground_truth = generate_sequence_with_TEs(
        base_len=260,
        num_TEs=4,
        allow_overlap=True
    )

    print("\n=== Artificial DNA sequence ===")
    print("Length:", len(seq))

    print("\n=== Ground truth transposons (what we inserted) ===")
    for te in ground_truth:
        start_1 = te['start'] + 1
        end_1 = te['end']       
        print(f"TE {te['id']}: start={start_1}, end={end_1}, length={te['end'] - te['start']}")

    detected = detect_transposons(seq)

    print("\n=== Detected transposons ===")
    if not detected:
        print("No candidates found.")
    else:
        for i, c in enumerate(detected, 1):
            start_1 = c['start'] + 1
            end_1 = c['end']
            print(
                f"Candidate {i}: start={start_1}, end={end_1}, "
                f"length={c['end'] - c['start']}, core_len={c['core_len']}, "
                f"DR(len={c['dr_len']}, seq={c['dr_seq']})"
            )

    print("\n=== Overlap between detected TEs and ground truth ===")
    for i, c in enumerate(detected, 1):
        print(f"\nDetected candidate {i} (start={c['start']}, end={c['end']}):")
        for te in ground_truth:
            ov = overlap(c['start'], c['end'], te['start'], te['end'])
            if ov > 0:
                print(
                    f"  overlaps GT TE {te['id']} "
                    f"(start={te['start']}, end={te['end']}) "
                    f"with overlap length={ov}"
                )


if __name__ == "__main__":
    main()
