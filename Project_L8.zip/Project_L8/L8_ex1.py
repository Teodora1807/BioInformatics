import requests
from collections import defaultdict

def rev_comp(seq: str) -> str:
    """Return reverse complement of a DNA sequence."""
    comp = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C'}
    return ''.join(comp.get(b, 'N') for b in reversed(seq))


def fetch_genome_from_ncbi(accession: str) -> str:
    url = (
        "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
        f"?db=nuccore&id={accession}&rettype=fasta&retmode=text"
    )

    print(f"\n[*] Downloading {accession} from NCBI...")
    r = requests.get(url)
    r.raise_for_status()
    text = r.text

    seq_lines = [line.strip() for line in text.splitlines() if not line.startswith(">")]
    sequence = "".join(seq_lines).upper()
    print(f"    Length: {len(sequence):,} bases")
    return sequence


def build_kmer_index(seq: str, k: int) -> dict:
    if k == 4:
        max_occ_per_kmer = 1000  
    elif k == 5:
        max_occ_per_kmer = 400   
    else:  # k == 6
        max_occ_per_kmer = 200    

    print(f"    - indexing {k}-mers (max_occ_per_kmer={max_occ_per_kmer})...")
    index = defaultdict(list)
    n = len(seq)
    for i in range(n - k + 1):
        kmer = seq[i:i+k]
        index[kmer].append(i)

    filtered = {}
    skipped = 0
    for kmer, pos_list in index.items():
        if len(pos_list) <= max_occ_per_kmer and len(pos_list) >= 2:
            # avem nevoie de cel puțin 2 apariții
            filtered[kmer] = pos_list
        else:
            skipped += 1

    print(f"      distinct {k}-mers: {len(index):,}, kept: {len(filtered):,}, skipped: {skipped:,}")
    return filtered

def detect_transposon_candidates(
    seq: str,
    ir_min_len: int = 4,
    ir_max_len: int = 6,
    min_te_len: int = 700,
    max_te_len: int = 12000,
    dr_min: int = 3,
    dr_max: int = 8,
    max_candidates: int = 5000,
):

    candidates = []

    for k in range(ir_min_len, ir_max_len + 1):
        print(f"\n[*] Searching for IRs with length k={k}")
        index = build_kmer_index(seq, k=k)

        processed_pairs = set()

        for s, pos_s_list in index.items():
            if len(candidates) >= max_candidates:
                print(f"[!] Reached candidate limit ({max_candidates}), stopping search early for k={k}")
                return sorted(candidates, key=lambda c: c["start"])

            rc = rev_comp(s)

            pair_key = tuple(sorted((s, rc)))
            if pair_key in processed_pairs:
                continue
            processed_pairs.add(pair_key)

            if rc not in index:
                continue

            pos_rc_list = index[rc]
            pos_s_list = sorted(pos_s_list)
            pos_rc_list = sorted(pos_rc_list)

            i, j = 0, 0
            while i < len(pos_s_list) and j < len(pos_rc_list):
                if len(candidates) >= max_candidates:
                    print(f"[!] Reached candidate limit ({max_candidates}), stopping search early.")
                    return sorted(candidates, key=lambda c: c["start"])

                posL = pos_s_list[i]
                posR = pos_rc_list[j]

                if posR <= posL:
                    j += 1
                    continue

                dist = posR - posL  
                if dist < min_te_len:
                    j += 1
                    continue
                if dist > max_te_len:
                    if posL < posR:
                        i += 1
                    else:
                        j += 1
                    continue

                te_start = posL
                te_end = posR + k  
                te_len = te_end - te_start

                best_dr = None
                for dr_len in range(dr_min, dr_max + 1):
                    left_start = te_start - dr_len
                    left_end = te_start
                    right_start = te_end
                    right_end = te_end + dr_len

                    if left_start < 0 or right_end > len(seq):
                        continue

                    left = seq[left_start:left_end]
                    right = seq[right_start:right_end]
                    if left == right:
                        best_dr = (left, dr_len)
                        break

                if best_dr is None:
                    j += 1
                    continue

                candidates.append(
                    {
                        "start": te_start,
                        "end": te_end,
                        "length": te_len,
                        "IR_len": k,
                        "IR_L": s,
                        "IR_R": rc,
                        "DR": best_dr,  
                    }
                )

                j += 1

    candidates.sort(key=lambda c: c["start"])
    return candidates


def analyze_overlaps(candidates, max_pairs_stored: int = 10000):

    overlaps = []
    nested = []

    n = len(candidates)
    for i in range(n):
        a = candidates[i]
        for j in range(i + 1, n):
            b = candidates[j]
            if b["start"] >= a["end"]:
                break 

            start_max = max(a["start"], b["start"])
            end_min = min(a["end"], b["end"])
            ov_len = end_min - start_max
            if ov_len <= 0:
                continue

            if len(overlaps) < max_pairs_stored:
                overlaps.append((i, j, ov_len))

            if a["start"] <= b["start"] and a["end"] >= b["end"]:
                if len(nested) < max_pairs_stored:
                    nested.append((i, j))
            elif b["start"] <= a["start"] and b["end"] >= a["end"]:
                if len(nested) < max_pairs_stored:
                    nested.append((j, i))

        # mică protecție: dacă am deja foarte multe perechi, nu continuăm cu alții
        if len(overlaps) >= max_pairs_stored and len(nested) >= max_pairs_stored:
            break

    return overlaps, nested

def analyze_genome(accession: str, name: str):

    genome = fetch_genome_from_ncbi(accession)

    print(f"\n=== Detecting transposable elements in {name} ({accession}) ===")
    candidates = detect_transposon_candidates(
        genome,
        ir_min_len=4,
        ir_max_len=6,
        min_te_len=700,
        max_te_len=12000,
        dr_min=3,
        dr_max=8,
        max_candidates=5000,   
    )

    print(f"\n[*] Total TE candidates found: {len(candidates):,}")

    # show first 20 candidates
    to_show = min(20, len(candidates))
    print(f"\n--- First {to_show} candidates (positions 1-based, inclusive) ---")
    for idx, c in enumerate(candidates[:to_show], 1):
        start_1 = c["start"] + 1
        end_1 = c["end"]     
        dr_info = f"DR={c['DR'][0]} (len={c['DR'][1]})"
        print(
            f"#{idx:02d}: start={start_1:,}, end={end_1:,}, "
            f"length={c['length']:,}, IR_len={c['IR_len']}, "
            f"IR_L={c['IR_L']}, IR_R={c['IR_R']}, {dr_info}"
        )

    # Overlap / nested (involving) analysis
    overlaps, nested = analyze_overlaps(candidates, max_pairs_stored=5000)
    print(f"\n[*] Overlapping TE pairs: {len(overlaps):,}")
    print(f"[*] Nested (involving) TE pairs: {len(nested):,}")

    if overlaps:
        print("\nExamples of overlapping pairs (max 5):")
        for (i, j, ov_len) in overlaps[:5]:
            A = candidates[i]
            B = candidates[j]
            print(
                f"  A({i}) [{A['start']+1:,}-{A['end']:,}] "
                f"overlaps B({j}) [{B['start']+1:,}-{B['end']:,}] "
                f"overlap_len={ov_len:,}"
            )

    if nested:
        print("\nExamples of nested (involving) pairs (max 5):")
        for (outer, inner) in nested[:5]:
            A = candidates[outer]
            B = candidates[inner]
            print(
                f"  Outer({outer}) [{A['start']+1:,}-{A['end']:,}] "
                f"contains Inner({inner}) [{B['start']+1:,}-{B['end']:,}]"
            )

    print("\n" + "=" * 80 + "\n")

def main():
    genomes = [
        ("NC_000913.3", "Escherichia coli K-12 MG1655"),
        ("NC_000964.3", "Bacillus subtilis subsp. subtilis 168"),
        ("NC_003198.1", "Salmonella enterica subsp. enterica serovar Typhi"),
    ]

    for acc, name in genomes:
        analyze_genome(acc, name)


if __name__ == "__main__":
    main()
