from typing import List

def mat_vec_mul(A: List[List[float]], x: List[float]) -> List[float]:
    n = len(A)
    return [sum(A[i][j] * x[j] for j in range(n)) for i in range(n)]

def read_matrix(n: int) -> List[List[float]]:
    A = []
    print(f"Enter the matrix A ({n} rows, each with {n} numbers):")
    for i in range(n):
        row = input(f"Row {i+1}: ").strip().split()
        if len(row) != n:
            raise ValueError(f"Row {i+1} must have exactly {n} values.")
        A.append([float(v) for v in row])
    return A

def read_vector(n: int) -> List[float]:
    print(f"Enter the initial vector x0 ({n} numbers):")
    parts = input("x0: ").strip().split()
    if len(parts) != n:
        raise ValueError(f"Vector must have exactly {n} values.")
    return [float(v) for v in parts]

def main():
    n = int(input("Enter size n (matrix is n x n): ").strip())
    if n <= 0:
        raise ValueError("n must be a positive integer.")

    A = read_matrix(n)
    x = read_vector(n)

    print("\nPredictions (5 discrete steps):")
    for step in range(1, 6):
        x = mat_vec_mul(A, x)
        # Pretty print with a little rounding
        formatted = " ".join(f"{val:.6g}" for val in x)
        print(f"x{step} = [{formatted}]")

if __name__ == "__main__":
    main()
