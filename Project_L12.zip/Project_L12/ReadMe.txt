Dumitru Teodora Iulia 1242
Ionescu Maria Magdalena 1242
Sîrbu Radu Constantin 1242