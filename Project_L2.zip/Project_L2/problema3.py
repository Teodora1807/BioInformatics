import textwrap
from collections import Counter
import tkinter as tk
from tkinter import filedialog, messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure


def find_alphabet(sequence: str):
    sequence = sequence.replace(" ", "").replace("\n", "")
    return sorted(set(sequence))


def parse_fasta(filepath: str):
    records = []
    header = None
    seq_chunks = []

    with open(filepath, "r", encoding="utf-8") as f:
        for raw in f:
            line = raw.rstrip("\n")
            if not line:
                continue
            if line.startswith(">"):
                if header is not None:
                    records.append((header, "".join(seq_chunks)))
                header = line[1:].strip()
                seq_chunks = []
            else:
                seq_chunks.append(line.strip())

    if header is not None:
        records.append((header, "".join(seq_chunks)))

    if not records:
        raise ValueError("Nu am găsit niciun record FASTA. Prima linie trebuie să înceapă cu '>'.")

    return records


def write_sample_fasta(filepath: str, kind: str = "DNA"):
    kind_up = kind.upper()
    if kind_up == "DNA":
        header = "sample_dna | id:DNA001 | description: Demo DNA sequence"
        raw_seq = "ATTGCCCCGAAT" * 10 + "TTGCAAGGCC"  # ~130 nt
    elif kind_up == "RNA":
        header = "sample_rna | id:RNA001 | description: Demo RNA sequence"
        raw_seq = ("AUUGCCCCGAAU" * 10 + "UUGCAAGGCC")  # ~132 nt (U în loc de T)
    else:
        header = "sample_prot | id:PROT001 | description: Demo protein sequence"
        raw_seq = "MKTFFVLVLLPLVSSQCVNLTTRNV" * 5  # ~120 aa, demo

    wrapped = "\n".join(textwrap.wrap(raw_seq, width=30))
    content = f">{header}\n{wrapped}\n"

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)


def sliding_window_analysis(sequence: str, window_size: int = 30):
    sequence = sequence.replace(" ", "").replace("\n", "")
    
    if len(sequence) < window_size:
        raise ValueError(f"Secvența prea scurtă! Necesită minim {window_size} caractere.")
    
    alphabet = sorted(set(sequence))
    positions = []
    frequencies = {symbol: [] for symbol in alphabet}

    for i in range(len(sequence) - window_size + 1):
        window = sequence[i:i + window_size]

        counts = Counter(window)

        positions.append(i + 1)
        for symbol in alphabet:
            freq = (counts.get(symbol, 0) / window_size) * 100
            frequencies[symbol].append(freq)
    
    return positions, frequencies, alphabet

class FastaSlidingWindowApp(tk.Tk):
    def _init_(self):
        super()._init_()
        self.title("FASTA Sliding Window Analyzer — Relative Frequencies Chart")
        self.geometry("1200x800")
        
        self.current_sequence = ""
        self.window_size = 30

        toolbar = tk.Frame(self)
        toolbar.pack(fill=tk.X, padx=10, pady=8)

        btn_open = tk.Button(toolbar, text="Open FASTA…", command=self.open_fasta,
                            bg="#4CAF50", fg="white", font=("Arial", 10, "bold"))
        btn_open.pack(side=tk.LEFT, padx=(0, 8))

        btn_sample_dna = tk.Button(toolbar, text="Generate Sample DNA",
                                   command=lambda: self.generate_sample(kind="DNA"),
                                   bg="#2196F3", fg="white")
        btn_sample_dna.pack(side=tk.LEFT, padx=(0, 8))

        btn_sample_rna = tk.Button(toolbar, text="Generate Sample RNA",
                                   command=lambda: self.generate_sample(kind="RNA"),
                                   bg="#2196F3", fg="white")
        btn_sample_rna.pack(side=tk.LEFT, padx=(0, 8))

        btn_analyze = tk.Button(toolbar, text="Analyze with Sliding Window",
                               command=self.analyze_with_sliding_window,
                               bg="#FF9800", fg="white", font=("Arial", 10, "bold"))
        btn_analyze.pack(side=tk.LEFT, padx=(0, 8))

        info_frame = tk.Frame(self, bg="#f0f0f0")
        info_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.info_label = tk.Label(info_frame, text="No sequence loaded", 
                                   bg="#f0f0f0", font=("Arial", 10))
        self.info_label.pack(pady=5)

        text_frame = tk.Frame(self)
        text_frame.pack(fill=tk.BOTH, expand=False, padx=10, pady=(0, 5))

        tk.Label(text_frame, text="Sequence Preview:", font=("Arial", 10, "bold")).pack(anchor=tk.W)
        
        self.txt = tk.Text(text_frame, wrap="word", font=("Consolas", 9), height=6)
        self.txt.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scroll = tk.Scrollbar(text_frame, command=self.txt.yview)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.txt.configure(yscrollcommand=scroll.set)

        self.chart_frame = tk.Frame(self)
        self.chart_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        welcome_fig = Figure(figsize=(10, 5), dpi=100)
        ax = welcome_fig.add_subplot(111)
        ax.text(0.5, 0.5, 
                "Welcome to FASTA Sliding Window Analyzer\n\n"
                "1. Open a FASTA file or Generate a sample\n"
                "2. Click 'Analyze with Sliding Window'\n"
                "3. View relative frequencies chart (window size: 30)",
                ha='center', va='center', fontsize=12, wrap=True)
        ax.axis('off')
        
        canvas = FigureCanvasTkAgg(welcome_fig, master=self.chart_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def _clear_text(self):
        self.txt.delete("1.0", tk.END)

    def _writeln(self, s=""):
        self.txt.insert(tk.END, s + "\n")
        self.txt.see(tk.END)

    def open_fasta(self):
        path = filedialog.askopenfilename(
            title="Select FASTA file",
            filetypes=[
                ("FASTA files", "*.fasta *.fa *.fna *.faa *.ffn *.frn"),
                ("All files", ".")
            ]
        )
        if not path:
            return
        try:
            records = parse_fasta(path)
            if not records:
                messagebox.showerror("Error", "No records found in FASTA file!")
                return

            header, seq = records[0]
            self.current_sequence = seq.replace(" ", "").replace("\n", "")
            
            self._clear_text()
            self._writeln(f"Loaded: {path}")
            self._writeln(f"Header: {header}")
            self._writeln(f"Sequence length: {len(self.current_sequence)} bp")
            self._writeln(f"\nFirst 200 characters:")
            self._writeln(self.current_sequence[:200] + "..." if len(self.current_sequence) > 200 else self.current_sequence)
            
            alphabet = find_alphabet(self.current_sequence)
            self.info_label.config(
                text=f"Sequence loaded | Length: {len(self.current_sequence)} bp | Alphabet: {', '.join(alphabet)}"
            )
            
        except Exception as e:
            messagebox.showerror("Parse error", f"Cannot parse FASTA:\n{e}")

    def generate_sample(self, kind: str):
        default_name = {"DNA": "sample_dna.fasta",
                        "RNA": "sample_rna.fasta",
                        "PROT": "sample_protein.fasta"}[kind.upper()]
        path = filedialog.asksaveasfilename(
            title=f"Save Sample {kind} FASTA",
            defaultextension=".fasta",
            initialfile=default_name,
            filetypes=[("FASTA files", ".fasta"), ("All files", ".*")]
        )
        if not path:
            return

        try:
            write_sample_fasta(path, kind=kind)
            records = parse_fasta(path)
            header, seq = records[0]
            self.current_sequence = seq.replace(" ", "").replace("\n", "")
            
            self._clear_text()
            self._writeln(f"Sample FASTA created: {path}")
            self._writeln(f"Header: {header}")
            self._writeln(f"Sequence length: {len(self.current_sequence)} bp")
            self._writeln(f"\nSequence:")
            self._writeln(self.current_sequence)
            
            alphabet = find_alphabet(self.current_sequence)
            self.info_label.config(
                text=f"Sample {kind} loaded | Length: {len(self.current_sequence)} bp | Alphabet: {', '.join(alphabet)}"
            )
            
        except Exception as e:
            messagebox.showerror("Error", f"Error generating/analyzing FASTA:\n{e}")

    def analyze_with_sliding_window(self):
        if not self.current_sequence:
            messagebox.showwarning("Warning", "Please load a FASTA file first!")
            return
        
        try:
            positions, frequencies, alphabet = sliding_window_analysis(
                self.current_sequence, self.window_size
            )
            
            for widget in self.chart_frame.winfo_children():
                widget.destroy()

            fig = Figure(figsize=(12, 6), dpi=100)
            ax = fig.add_subplot(111)

            colors = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899',
                     '#06b6d4', '#f97316', '#14b8a6', '#a855f7']
            
            for idx, symbol in enumerate(alphabet):
                color = colors[idx % len(colors)]
                ax.plot(positions, frequencies[symbol], label=symbol, 
                       color=color, linewidth=2, marker='o', markersize=2)
            
            ax.set_xlabel('Window Position (Start)', fontsize=12, fontweight='bold')
            ax.set_ylabel('Relative Frequency (%)', fontsize=12, fontweight='bold')
            ax.set_title(f'Sliding Window Analysis (Window Size: {self.window_size} bp)', 
                        fontsize=14, fontweight='bold')
            ax.legend(loc='best', fontsize=10)
            ax.grid(True, alpha=0.3, linestyle='--')
            ax.set_ylim(0, 100)
            
            fig.tight_layout()

            canvas = FigureCanvasTkAgg(fig, master=self.chart_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            
            messagebox.showinfo("Success", 
                              f"Analysis complete!\n"
                              f"Total windows: {len(positions)}\n"
                              f"Alphabet symbols: {len(alphabet)}")
            
        except Exception as e:
            messagebox.showerror("Analysis Error", f"Error during analysis:\n{e}")


if __name__ == "__main__":
    app = FastaSlidingWindowApp()
    app.mainloop()