def analyze_sequence_efficient(sequence):
    
    di_counts = {}
    tri_counts = {}
    
    for i in range(len(sequence)):
        
        if i <= len(sequence) - 2:
            dinuc = sequence[i:i+2]
            di_counts[dinuc] = di_counts.get(dinuc, 0) + 1
        
        
        if i <= len(sequence) - 3:
            trinuc = sequence[i:i+3]
            tri_counts[trinuc] = tri_counts.get(trinuc, 0) + 1
    
    total_di = len(sequence) - 1
    total_tri = len(sequence) - 2
    
    di_results = {}
    for combo, count in di_counts.items():
        percentage = (count / total_di) * 100 if total_di > 0 else 0
        di_results[combo] = {
            'count': count,
            'percentage': percentage
        }
    
    tri_results = {}
    for combo, count in tri_counts.items():
        percentage = (count / total_tri) * 100 if total_tri > 0 else 0
        tri_results[combo] = {
            'count': count,
            'percentage': percentage
        }
    
    return {
        'dinucleotides': di_results,
        'trinucleotides': tri_results,
        'total_di': total_di,
        'total_tri': total_tri
    }


def print_results(sequence, results):
   
    print("="*70)
    print("SEQUENCE ANALYSIS (Efficient Method - No Brute Force)")
    print("="*70)
    print(f"\nSequence: {sequence}")
    print(f"Length: {len(sequence)} characters\n")

    print("\n" + "="*70)
    print(f"DINUCLEOTIDES FOUND ({len(results['dinucleotides'])} unique)")
    print("="*70)
    print(f"{'Combination':<12} {'Count':<8} {'Percentage'}")
    print("-"*70)
    
    for combo in sorted(results['dinucleotides'].keys()):
        data = results['dinucleotides'][combo]
        print(f"{combo:<12} {data['count']:<8} {data['percentage']:.2f}%")
    
    print("\n" + "="*70)
    print(f"TRINUCLEOTIDES FOUND ({len(results['trinucleotides'])} unique)")
    print("="*70)
    print(f"{'Combination':<12} {'Count':<8} {'Percentage'}")
    print("-"*70)
    
    for combo in sorted(results['trinucleotides'].keys()):
        data = results['trinucleotides'][combo]
        print(f"{combo:<12} {data['count']:<8} {data['percentage']:.2f}%")
    
    print("\n" + "="*70)
    print("SUMMARY")
    print("="*70)
    print(f"Total dinucleotide positions: {results['total_di']}")
    print(f"Total trinucleotide positions: {results['total_tri']}")
    print(f"Unique dinucleotides found: {len(results['dinucleotides'])}")
    print(f"Unique trinucleotides found: {len(results['trinucleotides'])}")
    print("="*70)


def main():
    sequence1 = "ABAA"
    print("EXAMPLE 1:")
    results1 = analyze_sequence_efficient(sequence1)
    print_results(sequence1, results1)
    
    print("\n\n")
    
    sequence2 = "TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA"
    print("EXAMPLE 2:")
    results2 = analyze_sequence_efficient(sequence2)
    print_results(sequence2, results2)


if __name__ == "__main__":
    main()