Ionescu Maria Magdalena 
Dumitru Teodora Iulia
Sirbu Constantin Radu